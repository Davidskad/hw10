function createBookComponent(bookData) {
    // Create the main card div
    const cardDiv = document.createElement('div');
    cardDiv.classList.add(
        'col-12', 'col-sm-6', 'col-lg-4', 'col-xl-3', 'mb-4', 'book-card'
    );

    // Create Bootstrap card
    const card = document.createElement('div');
    card.classList.add('card', 'h-100');

    // Card body
    const cardBody = document.createElement('div');
    cardBody.classList.add('card-body');

    // Title
    const titleEl = document.createElement('h5');
    titleEl.classList.add('card-title');
    titleEl.textContent = bookData.title;

    // Author
    const authorEl = document.createElement('h6');
    authorEl.classList.add('card-subtitle', 'mb-2', 'text-muted');
    authorEl.textContent = bookData.author;

    // Pages
    const pagesEl = document.createElement('p');
    pagesEl.classList.add('card-text');
    pagesEl.textContent = `${bookData.numPages} pages`;

    // Description
    const descEl = document.createElement('p');
    descEl.classList.add('card-text');
    descEl.textContent = bookData.description;

    // Rating stars
    const ratingEl = document.createElement('div');
    ratingEl.classList.add('rating', 'mb-2');
    for (let i = 1; i <= 5; i++) {
        const starEl = document.createElement('i');
        starEl.classList.add('bi');

        if (i <= Math.floor(bookData.rating)) {
            starEl.classList.add('bi-star-fill');
        } else if (i - 0.5 <= bookData.rating) {
            starEl.classList.add('bi-star-half');
        } else {
            starEl.classList.add('bi-star');
        }

        ratingEl.appendChild(starEl);
    }

    // Add elements to card body
    cardBody.appendChild(titleEl);
    cardBody.appendChild(authorEl);
    cardBody.appendChild(pagesEl);
    cardBody.appendChild(descEl);
    cardBody.appendChild(ratingEl);

    // Add click event for favoriting
    card.addEventListener('click', () => {
        card.classList.toggle('bg-favorite');
    });

    // Assemble the card
    card.appendChild(cardBody);
    cardDiv.appendChild(card);

    return cardDiv;
}

// Main execution
const BOOKS = getBooks();
const booksDivNode = document.getElementById("book-list");

// Construct and add book components
BOOKS.forEach(book => {
    const bookComponent = createBookComponent(book);
    booksDivNode.appendChild(bookComponent);
});